package org.zeroxlab.julian.twofactor

import org.junit.Assert.*
import org.junit.Test
import org.zeroxlab.julian.twofactor.Base32.ByteBuffer
import java.io.ByteArrayInputStream

class Base32Test {
    @Test
    fun testBase32() {
        assertEquals("I5XW6ZCEMF4Q====", Base32.encode("GoodDay"))
        assertEquals("IJQXGZJTGI======", Base32.encode("Base32"))
        assertEquals("IFAUCQKB", Base32.encode("AAAAA"))
        assertEquals("KNUG652NMVKGQZKNN5XGK6I=", Base32.encode("ShowMeTheMoney"))
        assertEquals(
            "IFXEC4DQNRSUCRDBPFFWKZLQONCG6Y3UN5ZEC53BPE======",
            Base32.encode("AnAppleADayKeepsDoctorAway")
        )
    }

    @Test
    fun testUtil() {
        // 0111 0110 0111 1001
        // 01110 11001 11100 1
        val byte2: Byte = 0b01111000
        val int1 = 0xFF and byte2.toInt()
        assertEquals(0b01111000, int1)
        val byteBuffer = ByteBuffer(0b0111_0110)
        assertTrue(byteBuffer.isConsumable())
        assertEquals(0b000_1110.toByte(), byteBuffer.consume())
        assertFalse(byteBuffer.isConsumable())
        byteBuffer.append(0b0111_1001.toByte())
        assertTrue(byteBuffer.isConsumable())
        assertEquals(0b0001_1001.toByte(), byteBuffer.consume())
        assertTrue(byteBuffer.isConsumable())
        assertEquals(0b0001_1100.toByte(), byteBuffer.consume())
        assertFalse(byteBuffer.isConsumable())
        assertEquals(0b0001_0000.toByte(), byteBuffer.consume())
    }

    @Test
    fun testByte32InputStream() {
        val bytes = arrayOf(
            0b0111_1010.toByte(),
            0b0010_0110.toByte(),
            0b0111_1000.toByte()
        )
        val byteInputStream = ByteArrayInputStream(bytes.toByteArray())
        val base32InputStream = Base32.Base32InputStream(byteInputStream)
        assertEquals(0b0000_1111, base32InputStream.read())
        assertEquals(0b0000_1000, base32InputStream.read())
        assertEquals(0b0001_0011, base32InputStream.read())
        assertEquals(0b0000_0111, base32InputStream.read())
        assertEquals(0b0001_0000, base32InputStream.read())
        assertEquals(-1, base32InputStream.read())
    }
}
