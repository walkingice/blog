package org.zeroxlab.julian.twofactor

import org.junit.Test
import org.junit.Assert.*

class TotpTest {
    private val key = "GoAheadMakeMyDay"

    @Test
    fun totpTest() {
        val current = 1590080254249L // 2020-05-22 01:57:34
        // 000000000328C1B3
        val steps = Totp.getSteps(endTime = current, startTime = 0)
        assertEquals("455324", Totp.generate(key = key, steps = steps))
    }

    @Test
    fun totpTest2() {
        val current = 65535000L
        val steps = Totp.getSteps(endTime = current, startTime = 0, oneStepSize = 1)
        assertEquals("450722", Totp.generate(key = key, steps = steps))
    }

    @Test
    fun totpGen() {
        val code = Totp.generate(key = key)
        val secret = Base32.encode(key.toByteArray())
        println()
        println("key: $key")
        println("expected current code: $code")
        println("\tconvert key to secret: $secret")
        println("\tURI for generating Google Authenticator App QR Code")
        println("\totpauth://totp/foobar?digits=6&issuer=TEST&secret=$secret")
        println()
    }
}
