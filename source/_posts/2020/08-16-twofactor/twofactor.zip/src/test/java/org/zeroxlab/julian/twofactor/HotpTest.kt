package org.zeroxlab.julian.twofactor

import org.junit.Assert.*
import org.junit.Test
import org.zeroxlab.julian.twofactor.Hotp.toByteArray

class HotpTest {
    @Test
    fun testLongToArray() {
        val value: Long = 65535
        val array = value.toByteArray()
        assertEquals(8, array.size)
        assertEquals(0x00.toByte(), array[0])
        assertEquals(0x00.toByte(), array[1])
        assertEquals(0x00.toByte(), array[2])
        assertEquals(0x00.toByte(), array[3])
        assertEquals(0x00.toByte(), array[4])
        assertEquals(0x00.toByte(), array[5])
        assertEquals(0xFF.toByte(), array[6])
        assertEquals(0xFF.toByte(), array[7])

        // Kotlin Long is Java Long Long, 8 bytes number
        val longlongValue: Long = 0x1122334455667788
        val longlongArray = longlongValue.toByteArray()
        assertEquals(8, longlongArray.size)
        assertEquals(0x11.toByte(), longlongArray[0])
        assertEquals(0x22.toByte(), longlongArray[1])
        assertEquals(0x33.toByte(), longlongArray[2])
        assertEquals(0x44.toByte(), longlongArray[3])
        assertEquals(0x55.toByte(), longlongArray[4])
        assertEquals(0x66.toByte(), longlongArray[5])
        assertEquals(0x77.toByte(), longlongArray[6])
        assertEquals(0x88.toByte(), longlongArray[7])
    }

    @Test
    fun `test RFC4226 Section5-4 Example`() {
        //val hmac = 1f|86|98|69|0e|02|ca|16|61|85|50|ef|7f|19|da|8e|94|5b|55|5a|
        val hmac = arrayOf(
            0x1f.toByte(),
            0x86.toByte(),
            0x98.toByte(),
            0x69.toByte(),
            0x0e.toByte(),
            0x02.toByte(),
            0xca.toByte(),
            0x16.toByte(),
            0x61.toByte(),
            0x85.toByte(),
            0x50.toByte(),
            0xef.toByte(),
            0x7f.toByte(),
            0x19.toByte(),
            0xda.toByte(),
            0x8e.toByte(),
            0x94.toByte(),
            0x5b.toByte(),
            0x55.toByte(),
            0x5a.toByte()
        ).toByteArray()
        assertEquals("872921", Hotp.generate(hmac, 6))
    }

    @Test
    fun testGenerate() {
        // GoAheadMakeMyDay
        // val hmac = arrayOf(
        //     0x47.toByte(),
        //     0x6f.toByte(),
        //     0x41.toByte(),
        //     0x68.toByte(),
        //     0x65.toByte(),
        //     0x61.toByte(),
        //     0x64.toByte(),
        //     0x4d.toByte(),
        //     0x61.toByte(),
        //     0x6b.toByte(),
        //     0x65.toByte(),
        //     0x4d.toByte(),
        //     0x79.toByte(),
        //     0x44.toByte(),
        //     0x61.toByte(),
        //     0x79.toByte()
        // ).toByteArray()
        val key = "GoAheadMakeMyDay"
        val counter = 65535L
        assertEquals("450722", Hotp.generate(key = key, counter = counter, digit = 6))
    }
}
