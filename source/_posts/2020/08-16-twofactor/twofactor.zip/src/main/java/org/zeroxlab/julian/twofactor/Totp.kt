/**
 * BSD 0-clause license
 *
 * Copyright (C) 2020 by Julian Chu
 *
 * Permission to use, copy, modify, and/or distribute this software for any purpose
 * with or without fee is hereby granted.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
 * INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF
 * THIS SOFTWARE.
 */
package org.zeroxlab.julian.twofactor

import java.util.Calendar

/**
 * Simple implementation of RFC 6238
 */
object Totp {
    /**
     * Generate TOTP Value by current time
     */
    fun generate(key: String): String {
        return generate(key = key, steps = getSteps())
    }

    /**
     * Generate TOTP Value by given steps
     */
    fun generate(key: String, steps: Long): String {
        return Hotp.generate(key = key, counter = steps, digit = 6)
    }

    /**
     * To calculate how many steps since a specific start-time until end-time.
     * By default, since Jan. 1, 1970 GMT, until NOW, and count 30 seconds as 1 step.
     */
    fun getSteps(
        endTime: Long = Calendar.getInstance().time.time,
        startTime: Long = 0,
        oneStepSize: Int = 30
    ): Long {
        val seconds = endTime / 1000
        return (seconds - startTime) / oneStepSize
    }
}

