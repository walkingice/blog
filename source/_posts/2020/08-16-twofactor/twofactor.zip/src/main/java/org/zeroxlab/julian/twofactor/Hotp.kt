/**
 * BSD 0-clause license
 *
 * Copyright (C) 2020 by Julian Chu
 *
 * Permission to use, copy, modify, and/or distribute this software for any purpose
 * with or without fee is hereby granted.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
 * INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF
 * THIS SOFTWARE.
 */
package org.zeroxlab.julian.twofactor

import java.lang.reflect.UndeclaredThrowableException
import java.security.GeneralSecurityException
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Simple implementation of RFC 4226
 */
object Hotp {

    /**
     * Generate HOTP Value
     *
     * @param key Shared secret between client and server. ie: "This_is_my_pwd"
     * @param counter counter value(a.k.a. moving factor) to be shared between server and client.
     * @param digit number of digits in an HOTP value after truncation.
     */
    fun generate(key: String, counter: Long, digit: Int = 6): String {
        val counterInArray = counter.toByteArray()
        val hs = hmacSha(crypto = Crypto.SHA1, key = key.toByteArray(), counter = counterInArray)
        return generate(hs, digit)
    }

    /**
     * Generate HOTP Value. This is visible for test, because there is an example in RFC 4226.
     *
     * @param hmac HMAC-SHA1 result, calculated with key and counter
     * @param digit number of digits in an HOTP value after truncation.
     */
    internal fun generate(hmac: ByteArray, digit: Int = 6): String {
        val offset = hmac[hmac.size - 1].toInt() and 0xF  // 0 <= offset <= 15
        val p = ((hmac[offset].toInt() and 0x7F) shl 24) or  // not 0xFF, to avoid signed/unsigned
                ((hmac[offset + 1].toInt() and 0xFF) shl 16) or
                ((hmac[offset + 2].toInt() and 0xFF) shl 8) or
                (hmac[offset + 3].toInt() and 0xFF)

        // ie: 123 -> "123" -> "000000123" if digit = 6
        val digitInString = p.toString().padStart(digit, '0')
        return digitInString.substring(digitInString.length - digit)
    }

    /**
     * Convert 8 bytes Long value to byte array.
     * ie: for value 65535, the array will be [00 00 00 00 00 00 FF FF]
     */
    fun Long.toByteArray(): ByteArray {
        // 0x1234ab to "00000000001234AB"
        val hexStr = java.lang.Long.toHexString(this).padStart(16, '0').toUpperCase()
        val byteArray = ByteArray(hexStr.length / 2)
        val charArray = hexStr.toCharArray()
        for (i in charArray.indices step 2) {
            // for 0x12: a = 1, b = 2.
            // "12" -> "1" and "2" -> 0x1 and 0x2 -> 0x1 * 16 + 0x2
            val a = charToHexMap.getValue(charArray[i])
            val b = charToHexMap.getValue(charArray[i + 1])
            byteArray[i / 2] = (a * 16 + b).toByte()
        }
        return byteArray
    }

    private fun hmacSha(crypto: Crypto, key: ByteArray, counter: ByteArray): ByteArray {
        return try {
            val hmac = when (crypto) {
                Crypto.SHA1 -> Mac.getInstance(Crypto.SHA1.algorithm)
            }

            val macKey = SecretKeySpec(key, "RAW")
            hmac.init(macKey)
            hmac.doFinal(counter)
        } catch (gse: GeneralSecurityException) {
            throw UndeclaredThrowableException(gse)
        }
    }

    private val charToHexMap = mapOf<Char, Int>(
        '0' to 0x0,
        '1' to 0x1,
        '2' to 0x2,
        '3' to 0x3,
        '4' to 0x4,
        '5' to 0x5,
        '6' to 0x6,
        '7' to 0x7,
        '8' to 0x8,
        '9' to 0x9,
        'A' to 0xA,
        'B' to 0xB,
        'C' to 0xC,
        'D' to 0xD,
        'E' to 0xE,
        'F' to 0xF
    )
}

enum class Crypto(val algorithm: String) {
    SHA1("HmacSha1")
}
