/**
 * BSD 0-clause license
 *
 * Copyright (C) 2020 by Julian Chu
 *
 * Permission to use, copy, modify, and/or distribute this software for any purpose
 * with or without fee is hereby granted.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
 * INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF
 * THIS SOFTWARE.
 */
package org.zeroxlab.julian.twofactor

import java.io.ByteArrayInputStream
import java.io.InputStream
import java.lang.RuntimeException

/**
 * Simple Base32 encoding implementation
 */
object Base32 {

    private val base32Map = charArrayOf(
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
        'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
        '2', '3', '4', '5', '6', '7'
    )

    fun encode(string: String): String {
        return encode(string.toByteArray())
    }

    fun encode(bytes: ByteArray): String {
        val byteInputStream = ByteArrayInputStream(bytes)
        val base32InputStream = Base32InputStream(byteInputStream)
        val buffer = StringBuffer()

        while (true) {
            val r = base32InputStream.read()
            if (r == -1) {
                break
            }
            buffer.append(base32Map[r])
        }

        while (buffer.length % 8 != 0) {
            buffer.append("=")
        }

        return buffer.toString()
    }

    /**
     *
     * [11110000, 10101010, 00001111]
     * -> [11110, 00010, 10101, 00000, 1111 0]  append 0 because 1111 is only 4 bits
     * -> [0001_1110, 0000_0010, 0001_0101, 0000_0000, 0001_1110] byte to int
     *
     * visible for test
     */
    internal class Base32InputStream(private val inputStream: InputStream) : InputStream() {

        private var byteBuffer: ByteBuffer = ByteBuffer(0).apply { capacity = 0 }

        override fun read(): Int {
            if (byteBuffer.isConsumable()) {
                return byteBuffer.consume().toInt()
            }

            val readValue = inputStream.read()
            if (readValue == -1) {
                return if (byteBuffer.isNotEmpty()) {
                    // upstream reach end, flush buffer
                    byteBuffer.consume().toInt()
                } else {
                    -1
                }
            }
            byteBuffer.append(readValue.toByte())
            return byteBuffer.consume().toInt()
        }


    }

    /**
     * A helper class to get 5 bits from Bytes. It holds a buffer to store Byte value, we could
     * append one more byte to buffer, or get 5 bits from buffer.
     *
     * visible for test
     */
    internal class ByteBuffer(init: Byte) {
        var value: Int = init.toInt() and 0xFF
        var capacity = 8

        /**
         * to see if this buffer has 5 bits value or more
         */
        fun isConsumable() = capacity > 5

        /**
         * To see if this buffer has any bits of value
         */
        fun isNotEmpty() = capacity > 0

        /**
         * append one byte to buffer
         */
        fun append(another: Byte) {
            capacity += 8
            if (capacity > 16) {
                throw RuntimeException("exceed maximum capacity")
            }
            value = value shl 8
            value = value or (another.toInt() and 0xFF)
        }

        /**
         * get 5 bits value from buffer
         */
        fun consume(): Byte = if (capacity >= 5) {
            val rightMargin = capacity - 5
            val shifted: Int = (value shr rightMargin)
            capacity = rightMargin
            value = when (capacity) {
                0 -> 0
                1 -> value and 0b1
                2 -> value and 0b11
                3 -> value and 0b111
                4 -> value and 0b1111
                5 -> value and 0b11111
                6 -> value and 0b111111
                7 -> value and 0b1111111
                8 -> value and 0b11111111
                9 -> value and 0b111111111
                10 -> value and 0b1111111111
                11 -> value and 0b11111111111
                else -> throw RuntimeException("exceed maximum capacity")
            }
            shifted.toByte()
        } else {
            val rightMargin = 5 - capacity
            capacity = 0
            val shifted = value shl rightMargin
            value = 0
            shifted.toByte()
        }
    }
}
